Note that these outputs have the same x axis limits for both the mean and median.
